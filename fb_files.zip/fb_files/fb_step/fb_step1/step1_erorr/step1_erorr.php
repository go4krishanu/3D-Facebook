<html>
<head>
</head>
<body>


<!-- erorr Designing -->
<div id="error_design_format" style=" display:none; position:absolute;left:34.5%;top:71.3%; height:6%; width:32.9%; z-index:-1; background:#FFEBE8; box-shadow:0px 0px 7px 1px rgb(175,0,0); ">   </div>

</div>

<div style="position:absolute; left:43%; top:72.5%; display:none;" id="first_select"> Please first select Image file. </div>

<div style="position:absolute; left:35%; top:71.5%; font-size:14px; display:none;" id="not_valid_img">  Unable to process this photo. Please check your photo's format and try again.  <br>
We support these photo formats: JPG, GIF, GPEG and PNG.  </div>

</body>
</html>
